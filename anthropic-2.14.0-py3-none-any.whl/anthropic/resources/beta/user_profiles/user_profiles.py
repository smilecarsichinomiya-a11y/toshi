from __future__ import annotations

from typing import Dict, List, Union, Optional
from datetime import datetime
from itertools import chain
from typing_extensions import Literal

import httpx2

from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import is_given, path_template, strip_not_given
from ...._compat import cached_property
from .action_urls import (
    ActionURLs,
    AsyncActionURLs,
    ActionURLsWithRawResponse,
    AsyncActionURLsWithRawResponse,
    ActionURLsWithStreamingResponse,
    AsyncActionURLsWithStreamingResponse,
)
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ....pagination import SyncPageCursor, AsyncPageCursor
from ....types.beta import (
    BetaUserProfileExternalUserDetailsParams,
)
from ...._base_client import AsyncPaginator, make_request_options
from .providers.providers import (
    Providers,
    AsyncProviders,
    ProvidersWithRawResponse,
    AsyncProvidersWithRawResponse,
    ProvidersWithStreamingResponse,
    AsyncProvidersWithStreamingResponse,
)
from ....types.anthropic_beta_param import AnthropicBetaParam
from ....types.beta.beta_user_profile import BetaUserProfile
from ....types.beta.beta_deleted_user_profile import BetaDeletedUserProfile
from ....types.beta.beta_user_profile_enrollment_url import BetaUserProfileEnrollmentURL
from ....types.beta.beta_user_profile_external_user_details_params import BetaUserProfileExternalUserDetailsParams

__all__ = ["UserProfiles", "AsyncUserProfiles"]


class UserProfiles(SyncAPIResource):
    """
    Register the end customers that your platform serves, so each request can name who it's for. To get started, see the [User profiles guide](https://platform.claude.com/docs/en/manage-claude/user-profiles).
    """

    @cached_property
    def action_urls(self) -> ActionURLs:
        return ActionURLs(self._client)

    @cached_property
    def providers(self) -> Providers:
        return Providers(self._client)

    @cached_property
    def with_raw_response(self) -> UserProfilesWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return UserProfilesWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> UserProfilesWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return UserProfilesWithStreamingResponse(self)

    def create(
        self,
        *,
        access_type: Literal["application", "passthrough"] | Omit = omit,
        external_id: Optional[str] | Omit = omit,
        external_user_details: BetaUserProfileExternalUserDetailsParams | Omit = omit,
        external_user_onboarded_at: Union[str, datetime] | Omit = omit,
        metadata: Dict[str, str] | Omit = omit,
        name: Optional[str] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaUserProfile:
        """
        Register one of your end customers and get the ID to send on the requests you
        make for them.

        See the
        [User profiles guide](https://platform.claude.com/docs/en/manage-claude/user-profiles#create-a-profile-for-each-end-customer)
        for what to send.

        Args:
          access_type: How the platform uses the API for this entity. `application` (default): the
              profile represents an individual end-user of the platform's product.
              `passthrough`: the profile identifies a company the platform resells Claude
              access to.

              - `application` - The user profile represents an individual end-user of a
                product that the platform builds on the API. New profiles get this value by
                default.
              - `passthrough` - The user profile represents a company that the platform
                resells Claude access to.

          external_id: Platform's own identifier for this user. Not enforced unique. Maximum 255
              characters. Legacy field, accepted only under the `user-profiles-2026-03-24` and
              `user-profiles-2026-08-18` beta headers; without one of them, send
              `external_user_details.reference_id`.

          external_user_details: Details about the entity this profile represents, as the platform states them.
              Every field is optional. Not accepted under the legacy
              `user-profiles-2026-03-24` and `user-profiles-2026-08-18` beta headers, which
              take the top-level `external_id` (and, under `user-profiles-2026-08-18`,
              `external_user_onboarded_at`) instead.

          external_user_onboarded_at: When the entity this profile represents opened its account with the platform, in
              RFC 3339 format: for an `application` profile, when the end-user signed up; for
              a `passthrough` profile, when the company became the platform's customer. Must
              be a complete timestamp no more than 1 minute in the future. Optional. Legacy
              field, accepted only under the `user-profiles-2026-08-18` beta header; without a
              legacy header, send `external_user_details.onboarded_at`.

          metadata: Free-form key-value data to attach to this user profile. Maximum 16 keys, with
              keys up to 64 characters and values up to 512 characters. Values must be
              non-empty strings.

          name: Optional for all profiles. Real-world name of the entity this profile represents
              (company or individual); for a company the platform resells Claude access to
              (`access_type` `passthrough`), that company's name where known. Maximum 255
              characters.

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["user-profiles-2026-08-18"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "user-profiles-2026-08-18", **(extra_headers or {})}
        return self._post(
            "/v1/user_profiles",
            body={
                "access_type": access_type,
                "external_id": external_id,
                "external_user_details": external_user_details,
                "external_user_onboarded_at": external_user_onboarded_at,
                "metadata": metadata,
                "name": name,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.user_profiles.create",
                span_route="/v1/user_profiles",
                span_created_id="anthropic.user_profile.id",
            ),
            cast_to=BetaUserProfile,
        )

    def retrieve(
        self,
        user_profile_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaUserProfile:
        """
        Get a user profile by ID to check the details stored for it.

        See the
        [User profiles guide](https://platform.claude.com/docs/en/manage-claude/user-profiles)
        for how to set up and manage profiles.

        Args:
          user_profile_id: The ID of the user profile to get (`uprof_...`).

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not user_profile_id:
            raise ValueError(f"Expected a non-empty value for `user_profile_id` but received {user_profile_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["user-profiles-2026-08-18"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "user-profiles-2026-08-18", **(extra_headers or {})}
        return self._get(
            path_template("/v1/user_profiles/{user_profile_id}", user_profile_id=user_profile_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.user_profiles.retrieve",
                span_route="/v1/user_profiles/{user_profile_id}",
                span_attributes={"anthropic.user_profile.id": user_profile_id},
            ),
            cast_to=BetaUserProfile,
        )

    def update(
        self,
        user_profile_id: str,
        *,
        access_type: Optional[Literal["application", "passthrough"]] | Omit = omit,
        external_id: Optional[str] | Omit = omit,
        external_user_details: BetaUserProfileExternalUserDetailsParams | Omit = omit,
        external_user_onboarded_at: Union[str, datetime] | Omit = omit,
        metadata: Dict[str, str] | Omit = omit,
        name: Optional[str] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaUserProfile:
        """
        Change the details of a user profile, leaving the fields that you don't send as
        they are.

        See the
        [User profiles guide](https://platform.claude.com/docs/en/manage-claude/user-profiles#update-a-profile)
        for how each field is updated.

        Args:
          user_profile_id: The ID of the user profile to update (`uprof_...`).

          access_type: If present, replaces the stored access type. Omit to leave unchanged.

              - `application` - The user profile represents an individual end-user of a
                product that the platform builds on the API. New profiles get this value by
                default.
              - `passthrough` - The user profile represents a company that the platform
                resells Claude access to.

          external_id: If present, replaces the stored external_id. Omit to leave unchanged. Maximum
              255 characters. Legacy field, accepted only under the `user-profiles-2026-03-24`
              and `user-profiles-2026-08-18` beta headers; without one of them, send
              `external_user_details.reference_id`.

          external_user_details: Details about the entity this profile represents, as the platform states them.
              Each field sent replaces the stored value; omit a field to leave it unchanged.
              Once set, a value cannot be cleared and `null` is rejected. Not accepted under
              the legacy `user-profiles-2026-03-24` and `user-profiles-2026-08-18` beta
              headers.

          external_user_onboarded_at: If present, replaces the stored account creation time. Omit to leave unchanged;
              once set, the value cannot be cleared and `null` is rejected. Must be a complete
              RFC 3339 timestamp no more than 1 minute in the future. Legacy field, accepted
              only under the `user-profiles-2026-08-18` beta header; without a legacy header,
              send `external_user_details.onboarded_at`.

          metadata: Key-value pairs to merge into the stored metadata. Keys provided overwrite
              existing values. To remove a key, set its value to an empty string. Keys not
              provided are left unchanged. Maximum 16 keys, with keys up to 64 characters and
              values up to 512 characters.

          name: If present, replaces the stored name. Omit to leave unchanged. Maximum 255
              characters.

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not user_profile_id:
            raise ValueError(f"Expected a non-empty value for `user_profile_id` but received {user_profile_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["user-profiles-2026-08-18"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "user-profiles-2026-08-18", **(extra_headers or {})}
        return self._post(
            path_template("/v1/user_profiles/{user_profile_id}", user_profile_id=user_profile_id),
            body={
                "access_type": access_type,
                "external_id": external_id,
                "external_user_details": external_user_details,
                "external_user_onboarded_at": external_user_onboarded_at,
                "metadata": metadata,
                "name": name,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.user_profiles.update",
                span_route="/v1/user_profiles/{user_profile_id}",
                span_attributes={"anthropic.user_profile.id": user_profile_id},
            ),
            cast_to=BetaUserProfile,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        order: Literal["asc", "desc"] | Omit = omit,
        order_by: Literal["created_at", "name"] | Omit = omit,
        page: str | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> SyncPageCursor[BetaUserProfile]:
        """
        List the user profiles in your organization, newest first by default.

        See the
        [User profiles guide](https://platform.claude.com/docs/en/manage-claude/user-profiles)
        for how to set up and manage profiles.

        Args:
          limit: The maximum number of user profiles to return, from 1 to 100. Defaults to 20.

          order: The sort direction, applied to the field that `order_by` selects. Defaults to
              `desc`.

              - `asc` - Oldest first when `order_by` is `created_at`, or names in ascending
                order when `order_by` is `name`.
              - `desc` - Newest first when `order_by` is `created_at`, or names in descending
                order when `order_by` is `name`. This is the default.

          order_by: The field to sort user profiles by, in the direction that `order` sets. Defaults
              to `created_at`.

              - `created_at` - Sort by when each user profile was created. This is the
                default.
              - `name` - Sort by `name`, ignoring the case of ASCII letters. Profiles without
                a name come last in either direction.

          page: The cursor for the page to return, taken from `next_page` in a previous
              response.

              Leave it out to get the first page.

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["user-profiles-2026-08-18"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "user-profiles-2026-08-18", **(extra_headers or {})}
        return self._get_api_list(
            "/v1/user_profiles",
            page=SyncPageCursor[BetaUserProfile],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query={
                    "limit": limit,
                    "order": order,
                    "order_by": order_by,
                    "page": page,
                },
                qualifiers={"beta": "true"},
                span_name="anthropic.user_profiles.list",
                span_route="/v1/user_profiles",
            ),
            model=BetaUserProfile,
        )

    def delete(
        self,
        user_profile_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaDeletedUserProfile:
        """
        Delete a user profile, for example when the end customer closes their account.

        Stop sending the profile's ID first. See the
        [User profiles guide](https://platform.claude.com/docs/en/manage-claude/user-profiles#delete-a-profile)
        for what happens after a delete.

        Args:
          user_profile_id: The ID of the user profile to delete (`uprof_...`).

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not user_profile_id:
            raise ValueError(f"Expected a non-empty value for `user_profile_id` but received {user_profile_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["user-profiles-2026-08-18"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "user-profiles-2026-08-18", **(extra_headers or {})}
        return self._delete(
            path_template("/v1/user_profiles/{user_profile_id}", user_profile_id=user_profile_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.user_profiles.delete",
                span_route="/v1/user_profiles/{user_profile_id}",
                span_attributes={"anthropic.user_profile.id": user_profile_id},
            ),
            cast_to=BetaDeletedUserProfile,
        )

    def create_enrollment_url(
        self,
        user_profile_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaUserProfileEnrollmentURL:
        """
        Create a link that sends the profile's end customer to the Verification Portal
        from Claude Platform on AWS.

        On the Claude API, create an action URL instead. See
        [Send an end customer a link to the Verification Portal](https://platform.claude.com/docs/en/manage-claude/user-profiles-verification-portal)
        for when to create the link and what the end customer sees.

        Args:
          user_profile_id: The ID of the user profile to create an enrollment URL for (`uprof_...`).

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not user_profile_id:
            raise ValueError(f"Expected a non-empty value for `user_profile_id` but received {user_profile_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["user-profiles-2026-08-18"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "user-profiles-2026-08-18", **(extra_headers or {})}
        return self._post(
            path_template("/v1/user_profiles/{user_profile_id}/enrollment_url", user_profile_id=user_profile_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.user_profiles.create_enrollment_url",
                span_route="/v1/user_profiles/{user_profile_id}/enrollment_url",
                span_attributes={"anthropic.user_profile.id": user_profile_id},
            ),
            cast_to=BetaUserProfileEnrollmentURL,
        )


class AsyncUserProfiles(AsyncAPIResource):
    """
    Register the end customers that your platform serves, so each request can name who it's for. To get started, see the [User profiles guide](https://platform.claude.com/docs/en/manage-claude/user-profiles).
    """

    @cached_property
    def action_urls(self) -> AsyncActionURLs:
        return AsyncActionURLs(self._client)

    @cached_property
    def providers(self) -> AsyncProviders:
        return AsyncProviders(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncUserProfilesWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return AsyncUserProfilesWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncUserProfilesWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return AsyncUserProfilesWithStreamingResponse(self)

    async def create(
        self,
        *,
        access_type: Literal["application", "passthrough"] | Omit = omit,
        external_id: Optional[str] | Omit = omit,
        external_user_details: BetaUserProfileExternalUserDetailsParams | Omit = omit,
        external_user_onboarded_at: Union[str, datetime] | Omit = omit,
        metadata: Dict[str, str] | Omit = omit,
        name: Optional[str] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaUserProfile:
        """
        Register one of your end customers and get the ID to send on the requests you
        make for them.

        See the
        [User profiles guide](https://platform.claude.com/docs/en/manage-claude/user-profiles#create-a-profile-for-each-end-customer)
        for what to send.

        Args:
          access_type: How the platform uses the API for this entity. `application` (default): the
              profile represents an individual end-user of the platform's product.
              `passthrough`: the profile identifies a company the platform resells Claude
              access to.

              - `application` - The user profile represents an individual end-user of a
                product that the platform builds on the API. New profiles get this value by
                default.
              - `passthrough` - The user profile represents a company that the platform
                resells Claude access to.

          external_id: Platform's own identifier for this user. Not enforced unique. Maximum 255
              characters. Legacy field, accepted only under the `user-profiles-2026-03-24` and
              `user-profiles-2026-08-18` beta headers; without one of them, send
              `external_user_details.reference_id`.

          external_user_details: Details about the entity this profile represents, as the platform states them.
              Every field is optional. Not accepted under the legacy
              `user-profiles-2026-03-24` and `user-profiles-2026-08-18` beta headers, which
              take the top-level `external_id` (and, under `user-profiles-2026-08-18`,
              `external_user_onboarded_at`) instead.

          external_user_onboarded_at: When the entity this profile represents opened its account with the platform, in
              RFC 3339 format: for an `application` profile, when the end-user signed up; for
              a `passthrough` profile, when the company became the platform's customer. Must
              be a complete timestamp no more than 1 minute in the future. Optional. Legacy
              field, accepted only under the `user-profiles-2026-08-18` beta header; without a
              legacy header, send `external_user_details.onboarded_at`.

          metadata: Free-form key-value data to attach to this user profile. Maximum 16 keys, with
              keys up to 64 characters and values up to 512 characters. Values must be
              non-empty strings.

          name: Optional for all profiles. Real-world name of the entity this profile represents
              (company or individual); for a company the platform resells Claude access to
              (`access_type` `passthrough`), that company's name where known. Maximum 255
              characters.

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["user-profiles-2026-08-18"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "user-profiles-2026-08-18", **(extra_headers or {})}
        return await self._post(
            "/v1/user_profiles",
            body={
                "access_type": access_type,
                "external_id": external_id,
                "external_user_details": external_user_details,
                "external_user_onboarded_at": external_user_onboarded_at,
                "metadata": metadata,
                "name": name,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.user_profiles.create",
                span_route="/v1/user_profiles",
                span_created_id="anthropic.user_profile.id",
            ),
            cast_to=BetaUserProfile,
        )

    async def retrieve(
        self,
        user_profile_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaUserProfile:
        """
        Get a user profile by ID to check the details stored for it.

        See the
        [User profiles guide](https://platform.claude.com/docs/en/manage-claude/user-profiles)
        for how to set up and manage profiles.

        Args:
          user_profile_id: The ID of the user profile to get (`uprof_...`).

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not user_profile_id:
            raise ValueError(f"Expected a non-empty value for `user_profile_id` but received {user_profile_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["user-profiles-2026-08-18"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "user-profiles-2026-08-18", **(extra_headers or {})}
        return await self._get(
            path_template("/v1/user_profiles/{user_profile_id}", user_profile_id=user_profile_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.user_profiles.retrieve",
                span_route="/v1/user_profiles/{user_profile_id}",
                span_attributes={"anthropic.user_profile.id": user_profile_id},
            ),
            cast_to=BetaUserProfile,
        )

    async def update(
        self,
        user_profile_id: str,
        *,
        access_type: Optional[Literal["application", "passthrough"]] | Omit = omit,
        external_id: Optional[str] | Omit = omit,
        external_user_details: BetaUserProfileExternalUserDetailsParams | Omit = omit,
        external_user_onboarded_at: Union[str, datetime] | Omit = omit,
        metadata: Dict[str, str] | Omit = omit,
        name: Optional[str] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaUserProfile:
        """
        Change the details of a user profile, leaving the fields that you don't send as
        they are.

        See the
        [User profiles guide](https://platform.claude.com/docs/en/manage-claude/user-profiles#update-a-profile)
        for how each field is updated.

        Args:
          user_profile_id: The ID of the user profile to update (`uprof_...`).

          access_type: If present, replaces the stored access type. Omit to leave unchanged.

              - `application` - The user profile represents an individual end-user of a
                product that the platform builds on the API. New profiles get this value by
                default.
              - `passthrough` - The user profile represents a company that the platform
                resells Claude access to.

          external_id: If present, replaces the stored external_id. Omit to leave unchanged. Maximum
              255 characters. Legacy field, accepted only under the `user-profiles-2026-03-24`
              and `user-profiles-2026-08-18` beta headers; without one of them, send
              `external_user_details.reference_id`.

          external_user_details: Details about the entity this profile represents, as the platform states them.
              Each field sent replaces the stored value; omit a field to leave it unchanged.
              Once set, a value cannot be cleared and `null` is rejected. Not accepted under
              the legacy `user-profiles-2026-03-24` and `user-profiles-2026-08-18` beta
              headers.

          external_user_onboarded_at: If present, replaces the stored account creation time. Omit to leave unchanged;
              once set, the value cannot be cleared and `null` is rejected. Must be a complete
              RFC 3339 timestamp no more than 1 minute in the future. Legacy field, accepted
              only under the `user-profiles-2026-08-18` beta header; without a legacy header,
              send `external_user_details.onboarded_at`.

          metadata: Key-value pairs to merge into the stored metadata. Keys provided overwrite
              existing values. To remove a key, set its value to an empty string. Keys not
              provided are left unchanged. Maximum 16 keys, with keys up to 64 characters and
              values up to 512 characters.

          name: If present, replaces the stored name. Omit to leave unchanged. Maximum 255
              characters.

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not user_profile_id:
            raise ValueError(f"Expected a non-empty value for `user_profile_id` but received {user_profile_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["user-profiles-2026-08-18"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "user-profiles-2026-08-18", **(extra_headers or {})}
        return await self._post(
            path_template("/v1/user_profiles/{user_profile_id}", user_profile_id=user_profile_id),
            body={
                "access_type": access_type,
                "external_id": external_id,
                "external_user_details": external_user_details,
                "external_user_onboarded_at": external_user_onboarded_at,
                "metadata": metadata,
                "name": name,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.user_profiles.update",
                span_route="/v1/user_profiles/{user_profile_id}",
                span_attributes={"anthropic.user_profile.id": user_profile_id},
            ),
            cast_to=BetaUserProfile,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        order: Literal["asc", "desc"] | Omit = omit,
        order_by: Literal["created_at", "name"] | Omit = omit,
        page: str | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[BetaUserProfile, AsyncPageCursor[BetaUserProfile]]:
        """
        List the user profiles in your organization, newest first by default.

        See the
        [User profiles guide](https://platform.claude.com/docs/en/manage-claude/user-profiles)
        for how to set up and manage profiles.

        Args:
          limit: The maximum number of user profiles to return, from 1 to 100. Defaults to 20.

          order: The sort direction, applied to the field that `order_by` selects. Defaults to
              `desc`.

              - `asc` - Oldest first when `order_by` is `created_at`, or names in ascending
                order when `order_by` is `name`.
              - `desc` - Newest first when `order_by` is `created_at`, or names in descending
                order when `order_by` is `name`. This is the default.

          order_by: The field to sort user profiles by, in the direction that `order` sets. Defaults
              to `created_at`.

              - `created_at` - Sort by when each user profile was created. This is the
                default.
              - `name` - Sort by `name`, ignoring the case of ASCII letters. Profiles without
                a name come last in either direction.

          page: The cursor for the page to return, taken from `next_page` in a previous
              response.

              Leave it out to get the first page.

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["user-profiles-2026-08-18"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "user-profiles-2026-08-18", **(extra_headers or {})}
        return self._get_api_list(
            "/v1/user_profiles",
            page=AsyncPageCursor[BetaUserProfile],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query={
                    "limit": limit,
                    "order": order,
                    "order_by": order_by,
                    "page": page,
                },
                qualifiers={"beta": "true"},
                span_name="anthropic.user_profiles.list",
                span_route="/v1/user_profiles",
            ),
            model=BetaUserProfile,
        )

    async def delete(
        self,
        user_profile_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaDeletedUserProfile:
        """
        Delete a user profile, for example when the end customer closes their account.

        Stop sending the profile's ID first. See the
        [User profiles guide](https://platform.claude.com/docs/en/manage-claude/user-profiles#delete-a-profile)
        for what happens after a delete.

        Args:
          user_profile_id: The ID of the user profile to delete (`uprof_...`).

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not user_profile_id:
            raise ValueError(f"Expected a non-empty value for `user_profile_id` but received {user_profile_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["user-profiles-2026-08-18"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "user-profiles-2026-08-18", **(extra_headers or {})}
        return await self._delete(
            path_template("/v1/user_profiles/{user_profile_id}", user_profile_id=user_profile_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.user_profiles.delete",
                span_route="/v1/user_profiles/{user_profile_id}",
                span_attributes={"anthropic.user_profile.id": user_profile_id},
            ),
            cast_to=BetaDeletedUserProfile,
        )

    async def create_enrollment_url(
        self,
        user_profile_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaUserProfileEnrollmentURL:
        """
        Create a link that sends the profile's end customer to the Verification Portal
        from Claude Platform on AWS.

        On the Claude API, create an action URL instead. See
        [Send an end customer a link to the Verification Portal](https://platform.claude.com/docs/en/manage-claude/user-profiles-verification-portal)
        for when to create the link and what the end customer sees.

        Args:
          user_profile_id: The ID of the user profile to create an enrollment URL for (`uprof_...`).

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not user_profile_id:
            raise ValueError(f"Expected a non-empty value for `user_profile_id` but received {user_profile_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["user-profiles-2026-08-18"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "user-profiles-2026-08-18", **(extra_headers or {})}
        return await self._post(
            path_template("/v1/user_profiles/{user_profile_id}/enrollment_url", user_profile_id=user_profile_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.user_profiles.create_enrollment_url",
                span_route="/v1/user_profiles/{user_profile_id}/enrollment_url",
                span_attributes={"anthropic.user_profile.id": user_profile_id},
            ),
            cast_to=BetaUserProfileEnrollmentURL,
        )


class UserProfilesWithRawResponse:
    def __init__(self, user_profiles: UserProfiles) -> None:
        self._user_profiles = user_profiles

        self.create = to_raw_response_wrapper(
            user_profiles.create,
        )
        self.retrieve = to_raw_response_wrapper(
            user_profiles.retrieve,
        )
        self.update = to_raw_response_wrapper(
            user_profiles.update,
        )
        self.list = to_raw_response_wrapper(
            user_profiles.list,
        )
        self.delete = to_raw_response_wrapper(
            user_profiles.delete,
        )
        self.create_enrollment_url = to_raw_response_wrapper(
            user_profiles.create_enrollment_url,
        )

    @cached_property
    def action_urls(self) -> ActionURLsWithRawResponse:
        return ActionURLsWithRawResponse(self._user_profiles.action_urls)

    @cached_property
    def providers(self) -> ProvidersWithRawResponse:
        return ProvidersWithRawResponse(self._user_profiles.providers)


class AsyncUserProfilesWithRawResponse:
    def __init__(self, user_profiles: AsyncUserProfiles) -> None:
        self._user_profiles = user_profiles

        self.create = async_to_raw_response_wrapper(
            user_profiles.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            user_profiles.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            user_profiles.update,
        )
        self.list = async_to_raw_response_wrapper(
            user_profiles.list,
        )
        self.delete = async_to_raw_response_wrapper(
            user_profiles.delete,
        )
        self.create_enrollment_url = async_to_raw_response_wrapper(
            user_profiles.create_enrollment_url,
        )

    @cached_property
    def action_urls(self) -> AsyncActionURLsWithRawResponse:
        return AsyncActionURLsWithRawResponse(self._user_profiles.action_urls)

    @cached_property
    def providers(self) -> AsyncProvidersWithRawResponse:
        return AsyncProvidersWithRawResponse(self._user_profiles.providers)


class UserProfilesWithStreamingResponse:
    def __init__(self, user_profiles: UserProfiles) -> None:
        self._user_profiles = user_profiles

        self.create = to_streamed_response_wrapper(
            user_profiles.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            user_profiles.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            user_profiles.update,
        )
        self.list = to_streamed_response_wrapper(
            user_profiles.list,
        )
        self.delete = to_streamed_response_wrapper(
            user_profiles.delete,
        )
        self.create_enrollment_url = to_streamed_response_wrapper(
            user_profiles.create_enrollment_url,
        )

    @cached_property
    def action_urls(self) -> ActionURLsWithStreamingResponse:
        return ActionURLsWithStreamingResponse(self._user_profiles.action_urls)

    @cached_property
    def providers(self) -> ProvidersWithStreamingResponse:
        return ProvidersWithStreamingResponse(self._user_profiles.providers)


class AsyncUserProfilesWithStreamingResponse:
    def __init__(self, user_profiles: AsyncUserProfiles) -> None:
        self._user_profiles = user_profiles

        self.create = async_to_streamed_response_wrapper(
            user_profiles.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            user_profiles.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            user_profiles.update,
        )
        self.list = async_to_streamed_response_wrapper(
            user_profiles.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            user_profiles.delete,
        )
        self.create_enrollment_url = async_to_streamed_response_wrapper(
            user_profiles.create_enrollment_url,
        )

    @cached_property
    def action_urls(self) -> AsyncActionURLsWithStreamingResponse:
        return AsyncActionURLsWithStreamingResponse(self._user_profiles.action_urls)

    @cached_property
    def providers(self) -> AsyncProvidersWithStreamingResponse:
        return AsyncProvidersWithStreamingResponse(self._user_profiles.providers)
