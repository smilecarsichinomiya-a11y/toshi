from __future__ import annotations

from typing import Dict, List, Optional

import httpx2

from .members import (
    Members,
    AsyncMembers,
    MembersWithRawResponse,
    AsyncMembersWithRawResponse,
    MembersWithStreamingResponse,
    AsyncMembersWithStreamingResponse,
)
from ....._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ....._utils import is_given, path_template, strip_not_given
from ....._compat import cached_property
from .rate_limits import (
    RateLimits,
    AsyncRateLimits,
    RateLimitsWithRawResponse,
    AsyncRateLimitsWithRawResponse,
    RateLimitsWithStreamingResponse,
    AsyncRateLimitsWithStreamingResponse,
)
from ....._resource import SyncAPIResource, AsyncAPIResource
from ....._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .....pagination import SyncPage, AsyncPage
from ....._base_client import AsyncPaginator, make_request_options
from .service_accounts import (
    ServiceAccounts,
    AsyncServiceAccounts,
    ServiceAccountsWithRawResponse,
    AsyncServiceAccountsWithRawResponse,
    ServiceAccountsWithStreamingResponse,
    AsyncServiceAccountsWithStreamingResponse,
)
from .....types.beta.organization import (
    BetaInferenceDataPrivacyCreateParam,
    BetaInferenceDataPrivacyUpdateParam,
)
from .....types.anthropic_beta_param import AnthropicBetaParam
from .....types.beta.organization.beta_workspace import BetaWorkspace
from .....types.beta.organization.beta_data_residency_create_config_param import BetaDataResidencyCreateConfigParam
from .....types.beta.organization.beta_data_residency_update_config_param import BetaDataResidencyUpdateConfigParam
from .....types.beta.organization.beta_inference_data_privacy_create_param import BetaInferenceDataPrivacyCreateParam
from .....types.beta.organization.beta_inference_data_privacy_update_param import BetaInferenceDataPrivacyUpdateParam

__all__ = ["Workspaces", "AsyncWorkspaces"]


class Workspaces(SyncAPIResource):
    @cached_property
    def rate_limits(self) -> RateLimits:
        return RateLimits(self._client)

    @cached_property
    def members(self) -> Members:
        return Members(self._client)

    @cached_property
    def service_accounts(self) -> ServiceAccounts:
        return ServiceAccounts(self._client)

    @cached_property
    def with_raw_response(self) -> WorkspacesWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return WorkspacesWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> WorkspacesWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return WorkspacesWithStreamingResponse(self)

    def create(
        self,
        *,
        name: str,
        data_residency: Optional[BetaDataResidencyCreateConfigParam] | Omit = omit,
        display_color: Optional[str] | Omit = omit,
        external_key_id: Optional[str] | Omit = omit,
        inference_data_privacy: Optional[BetaInferenceDataPrivacyCreateParam] | Omit = omit,
        tags: Optional[Dict[str, str]] | Omit = omit,
        user_profile_id: Optional[str] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaWorkspace:
        """
        Create Workspace

        Args:
          name: Name of the Workspace.

          data_residency: Data residency configuration for the workspace. If omitted, defaults to
              `workspace_geo: "us"`, `allowed_inference_geos: "unrestricted"`, and
              `default_inference_geo: "global"`.

          display_color: Hex color code representing the Workspace in the Anthropic Console.

          external_key_id: ID of the customer-managed encryption key (CMEK) configuration to use for this
              Workspace. Setting this field requires CMEK to be enabled for your organization.
              When set, data stored for this Workspace is encrypted with the referenced key.
              Create key configurations with the External Keys API. On Claude Platform on AWS
              the value for an AWS KMS key is the key's ARN, and your organization's own key
              must be a single-Region key in the same Region as the Workspace. If that key is
              outside the Workspace's AWS account, it can be attached only by updating an
              active Workspace. On that platform the key is validated against this Workspace
              when it is attached, so a key-policy problem is reported as an error on this
              request. This field is write-once: once a key is attached to a Workspace it
              cannot be detached or replaced. To rotate key material, rotate the underlying
              key on your cloud KMS; the `external_key_id` stays the same.

          inference_data_privacy: Where the Workspace's retained inference data and transcript copies go, and
              whether Anthropic's human review applies. Requires the `efs-2026-10-01`
              `anthropic-beta` value. When omitted, `safeguards_storage` and
              `transcripts_storage` are `internal` and `human_review` is `enabled`. Cannot be
              null. An Admin API key can't set this field, because it doesn't belong to a user
              or a service account. Use an API key that belongs to one, or an OAuth token.

          tags: User-defined tags as string key-value pairs. Keys may not begin with
              `anthropic`.

          user_profile_id: ID of a user profile to attach to the Workspace. Every inference request through
              the Workspace must then name this user profile; the API rejects a request that
              names none or a different one. The user profile can't be replaced or removed
              later; only deleting the user profile clears it.

          betas: Optional header to specify the beta version(s) you want to use.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          BetaApprovalRequiredError:

          ExternalKeyValidationFailedError:

          ExternalKeyValidationTimedOutError:

          BetaExternalStorageNotAvailableError:

          BetaGrantRequiredError:

          BetaHumanReviewNotAvailableError:

          BetaHumanReviewOnWithExternalStorageError:

          BetaInvalidStorageARNError:

          KeyProfileMismatchError:

          BetaOrganizationNotEligibleError:

          BetaStorageNotAttachableError:

          StorageProfileMismatchError:

          BetaStorageVerificationFailedError:

          BetaTranscriptsStorageRequiredError:

          UserProfileNotFoundError:

          WorkspacePolicyViolationError:

          SandboxEgressRestrictedError:

          ExternalKeyChangedError:

          BetaAuthorizationCheckUnavailableError:

          WorkspaceCreatedIncompleteError:
        """
        extra_headers = {
            **strip_not_given({"anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given}),
            **(extra_headers or {}),
        }
        return self._post(
            "/v1/organizations/workspaces",
            body={
                "name": name,
                "data_residency": data_residency,
                "display_color": display_color,
                "external_key_id": external_key_id,
                "inference_data_privacy": inference_data_privacy,
                "tags": tags,
                "user_profile_id": user_profile_id,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.organization.workspaces.create",
                span_route="/v1/organizations/workspaces",
                span_created_id="anthropic.organization.workspace.id",
            ),
            cast_to=BetaWorkspace,
        )

    def retrieve(
        self,
        workspace_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaWorkspace:
        """Get Workspace

        Args:
          workspace_id: ID of the Workspace.

          betas: Optional.

        Send `efs-2026-10-01` in this header to use this endpoint's beta
              features: additional parameters, accepted values and response fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        extra_headers = {
            **strip_not_given({"anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given}),
            **(extra_headers or {}),
        }
        return self._get(
            path_template("/v1/organizations/workspaces/{workspace_id}", workspace_id=workspace_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.organization.workspaces.retrieve",
                span_route="/v1/organizations/workspaces/{workspace_id}",
                span_attributes={"anthropic.organization.workspace.id": workspace_id},
            ),
            cast_to=BetaWorkspace,
        )

    def update(
        self,
        workspace_id: str,
        *,
        data_residency: Optional[BetaDataResidencyUpdateConfigParam] | Omit = omit,
        display_color: str | Omit = omit,
        external_key_id: str | Omit = omit,
        inference_data_privacy: Optional[BetaInferenceDataPrivacyUpdateParam] | Omit = omit,
        name: str | Omit = omit,
        tags: Optional[Dict[str, Optional[str]]] | Omit = omit,
        user_profile_id: str | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaWorkspace:
        """
        Update Workspace

        Args:
          data_residency: Data residency configuration for the workspace.

          display_color: Hex color code representing the Workspace in the Anthropic Console.

          external_key_id: ID of the customer-managed encryption key (CMEK) configuration to use for this
              Workspace. Setting this field requires CMEK to be enabled for your organization.
              When set, data stored for this Workspace is encrypted with the referenced key.
              Create key configurations with the External Keys API. On Claude Platform on AWS
              the value for an AWS KMS key is the key's ARN, and your organization's own key
              must be a single-Region key in the same Region as the Workspace. If that key is
              outside the Workspace's AWS account, it can be attached only by updating an
              active Workspace. On that platform the key is validated against this Workspace
              when it is attached, so a key-policy problem is reported as an error on this
              request. This field is write-once: once a key is attached to a Workspace it
              cannot be detached or replaced. To rotate key material, rotate the underlying
              key on your cloud KMS; the `external_key_id` stays the same.

          inference_data_privacy: Changes to where the Workspace's retained inference data and transcript copies
              go, and to whether Anthropic's human review applies. Requires the
              `efs-2026-10-01` `anthropic-beta` value. An omitted member is unchanged. Cannot
              be null. An Admin API key can't set this field, because it doesn't belong to a
              user or a service account. Use an API key that belongs to one, or an OAuth
              token.

          name: Name of the Workspace.

          tags: User-defined tags as string key-value pairs. Keys may not begin with
              `anthropic`.

          user_profile_id: ID of a user profile to attach to the Workspace. Every inference request through
              the Workspace must then name this user profile; the API rejects a request that
              names none or a different one. Once set, it can't be replaced or removed
              (sending the same ID again changes nothing); only deleting the user profile
              clears it. It can't be set on a Workspace whose External Key isn't bound to this
              user profile. The default Workspace can't have a user profile.

          betas: Optional. Send `efs-2026-10-01` in this header to use this endpoint's beta
              features: additional parameters, accepted values and response fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          BetaApprovalRequiredError:

          ExternalKeyValidationFailedError:

          ExternalKeyValidationTimedOutError:

          BetaExternalStorageNotAvailableError:

          BetaGrantRequiredError:

          BetaHumanReviewNotAvailableError:

          BetaHumanReviewOnWithExternalStorageError:

          BetaInvalidStorageARNError:

          KeyProfileMismatchError:

          BetaOrganizationNotEligibleError:

          BetaStorageAttachLimitReachedError:

          BetaStorageNotAttachableError:

          StorageProfileMismatchError:

          BetaStorageProfileStillRequiredError:

          BetaStorageVerificationFailedError:

          BetaTranscriptsStorageRequiredError:

          UserProfileNotFoundError:

          WorkspacePolicyViolationError:

          SandboxEgressRestrictedError:

          ExternalKeyChangedError:

          BetaStorageChangedConcurrentlyError:

          BetaWorkspaceChangedConcurrentlyError:

          BetaAuthorizationCheckUnavailableError:

          ChangeOutcomeUnknownError:
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        extra_headers = {
            **strip_not_given({"anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given}),
            **(extra_headers or {}),
        }
        return self._post(
            path_template("/v1/organizations/workspaces/{workspace_id}", workspace_id=workspace_id),
            body={
                "data_residency": data_residency,
                "display_color": display_color,
                "external_key_id": external_key_id,
                "inference_data_privacy": inference_data_privacy,
                "name": name,
                "tags": tags,
                "user_profile_id": user_profile_id,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.organization.workspaces.update",
                span_route="/v1/organizations/workspaces/{workspace_id}",
                span_attributes={"anthropic.organization.workspace.id": workspace_id},
            ),
            cast_to=BetaWorkspace,
        )

    def list(
        self,
        *,
        after_id: str | Omit = omit,
        before_id: str | Omit = omit,
        ids: SequenceNotStr[str] | Omit = omit,
        include_archived: bool | Omit = omit,
        include_default: bool | Omit = omit,
        limit: int | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> SyncPage[BetaWorkspace]:
        """
        List Workspaces

        Args:
          after_id: ID of the object to use as a cursor for pagination. When provided, returns the
              page of results immediately after this object.

          before_id: ID of the object to use as a cursor for pagination. When provided, returns the
              page of results immediately before this object.

          ids: Only the Workspaces with these IDs, at most 100. `include_archived` and
              `include_default` still apply, and IDs of Workspaces the caller can't list are
              left out.

          include_archived: Whether to include Workspaces that have been archived in the response

          include_default: Whether to include the organization's default Workspace in the response

          limit: Number of items to return per page.

              Defaults to `20`. Ranges from `1` to `1000`.

          betas: Optional. Send `efs-2026-10-01` in this header to use this endpoint's beta
              features: additional parameters, accepted values and response fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given({"anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given}),
            **(extra_headers or {}),
        }
        return self._get_api_list(
            "/v1/organizations/workspaces",
            page=SyncPage[BetaWorkspace],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query={
                    "after_id": after_id,
                    "before_id": before_id,
                    "ids": ids,
                    "include_archived": include_archived,
                    "include_default": include_default,
                    "limit": limit,
                },
                qualifiers={"beta": "true"},
                span_name="anthropic.organization.workspaces.list",
                span_route="/v1/organizations/workspaces",
            ),
            model=BetaWorkspace,
        )

    def archive(
        self,
        workspace_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaWorkspace:
        """Archive Workspace

        Args:
          betas: Optional.

        Send `efs-2026-10-01` in this header to use this endpoint's beta
              features: additional parameters, accepted values and response fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          SandboxEgressRestrictedError:

          StorageAttachedDuringArchiveError:
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        extra_headers = {
            **strip_not_given({"anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given}),
            **(extra_headers or {}),
        }
        return self._post(
            path_template("/v1/organizations/workspaces/{workspace_id}/archive", workspace_id=workspace_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.organization.workspaces.archive",
                span_route="/v1/organizations/workspaces/{workspace_id}/archive",
                span_attributes={"anthropic.organization.workspace.id": workspace_id},
            ),
            cast_to=BetaWorkspace,
        )


class AsyncWorkspaces(AsyncAPIResource):
    @cached_property
    def rate_limits(self) -> AsyncRateLimits:
        return AsyncRateLimits(self._client)

    @cached_property
    def members(self) -> AsyncMembers:
        return AsyncMembers(self._client)

    @cached_property
    def service_accounts(self) -> AsyncServiceAccounts:
        return AsyncServiceAccounts(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncWorkspacesWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return AsyncWorkspacesWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncWorkspacesWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return AsyncWorkspacesWithStreamingResponse(self)

    async def create(
        self,
        *,
        name: str,
        data_residency: Optional[BetaDataResidencyCreateConfigParam] | Omit = omit,
        display_color: Optional[str] | Omit = omit,
        external_key_id: Optional[str] | Omit = omit,
        inference_data_privacy: Optional[BetaInferenceDataPrivacyCreateParam] | Omit = omit,
        tags: Optional[Dict[str, str]] | Omit = omit,
        user_profile_id: Optional[str] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaWorkspace:
        """
        Create Workspace

        Args:
          name: Name of the Workspace.

          data_residency: Data residency configuration for the workspace. If omitted, defaults to
              `workspace_geo: "us"`, `allowed_inference_geos: "unrestricted"`, and
              `default_inference_geo: "global"`.

          display_color: Hex color code representing the Workspace in the Anthropic Console.

          external_key_id: ID of the customer-managed encryption key (CMEK) configuration to use for this
              Workspace. Setting this field requires CMEK to be enabled for your organization.
              When set, data stored for this Workspace is encrypted with the referenced key.
              Create key configurations with the External Keys API. On Claude Platform on AWS
              the value for an AWS KMS key is the key's ARN, and your organization's own key
              must be a single-Region key in the same Region as the Workspace. If that key is
              outside the Workspace's AWS account, it can be attached only by updating an
              active Workspace. On that platform the key is validated against this Workspace
              when it is attached, so a key-policy problem is reported as an error on this
              request. This field is write-once: once a key is attached to a Workspace it
              cannot be detached or replaced. To rotate key material, rotate the underlying
              key on your cloud KMS; the `external_key_id` stays the same.

          inference_data_privacy: Where the Workspace's retained inference data and transcript copies go, and
              whether Anthropic's human review applies. Requires the `efs-2026-10-01`
              `anthropic-beta` value. When omitted, `safeguards_storage` and
              `transcripts_storage` are `internal` and `human_review` is `enabled`. Cannot be
              null. An Admin API key can't set this field, because it doesn't belong to a user
              or a service account. Use an API key that belongs to one, or an OAuth token.

          tags: User-defined tags as string key-value pairs. Keys may not begin with
              `anthropic`.

          user_profile_id: ID of a user profile to attach to the Workspace. Every inference request through
              the Workspace must then name this user profile; the API rejects a request that
              names none or a different one. The user profile can't be replaced or removed
              later; only deleting the user profile clears it.

          betas: Optional header to specify the beta version(s) you want to use.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          BetaApprovalRequiredError:

          ExternalKeyValidationFailedError:

          ExternalKeyValidationTimedOutError:

          BetaExternalStorageNotAvailableError:

          BetaGrantRequiredError:

          BetaHumanReviewNotAvailableError:

          BetaHumanReviewOnWithExternalStorageError:

          BetaInvalidStorageARNError:

          KeyProfileMismatchError:

          BetaOrganizationNotEligibleError:

          BetaStorageNotAttachableError:

          StorageProfileMismatchError:

          BetaStorageVerificationFailedError:

          BetaTranscriptsStorageRequiredError:

          UserProfileNotFoundError:

          WorkspacePolicyViolationError:

          SandboxEgressRestrictedError:

          ExternalKeyChangedError:

          BetaAuthorizationCheckUnavailableError:

          WorkspaceCreatedIncompleteError:
        """
        extra_headers = {
            **strip_not_given({"anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given}),
            **(extra_headers or {}),
        }
        return await self._post(
            "/v1/organizations/workspaces",
            body={
                "name": name,
                "data_residency": data_residency,
                "display_color": display_color,
                "external_key_id": external_key_id,
                "inference_data_privacy": inference_data_privacy,
                "tags": tags,
                "user_profile_id": user_profile_id,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.organization.workspaces.create",
                span_route="/v1/organizations/workspaces",
                span_created_id="anthropic.organization.workspace.id",
            ),
            cast_to=BetaWorkspace,
        )

    async def retrieve(
        self,
        workspace_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaWorkspace:
        """Get Workspace

        Args:
          workspace_id: ID of the Workspace.

          betas: Optional.

        Send `efs-2026-10-01` in this header to use this endpoint's beta
              features: additional parameters, accepted values and response fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        extra_headers = {
            **strip_not_given({"anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given}),
            **(extra_headers or {}),
        }
        return await self._get(
            path_template("/v1/organizations/workspaces/{workspace_id}", workspace_id=workspace_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.organization.workspaces.retrieve",
                span_route="/v1/organizations/workspaces/{workspace_id}",
                span_attributes={"anthropic.organization.workspace.id": workspace_id},
            ),
            cast_to=BetaWorkspace,
        )

    async def update(
        self,
        workspace_id: str,
        *,
        data_residency: Optional[BetaDataResidencyUpdateConfigParam] | Omit = omit,
        display_color: str | Omit = omit,
        external_key_id: str | Omit = omit,
        inference_data_privacy: Optional[BetaInferenceDataPrivacyUpdateParam] | Omit = omit,
        name: str | Omit = omit,
        tags: Optional[Dict[str, Optional[str]]] | Omit = omit,
        user_profile_id: str | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaWorkspace:
        """
        Update Workspace

        Args:
          data_residency: Data residency configuration for the workspace.

          display_color: Hex color code representing the Workspace in the Anthropic Console.

          external_key_id: ID of the customer-managed encryption key (CMEK) configuration to use for this
              Workspace. Setting this field requires CMEK to be enabled for your organization.
              When set, data stored for this Workspace is encrypted with the referenced key.
              Create key configurations with the External Keys API. On Claude Platform on AWS
              the value for an AWS KMS key is the key's ARN, and your organization's own key
              must be a single-Region key in the same Region as the Workspace. If that key is
              outside the Workspace's AWS account, it can be attached only by updating an
              active Workspace. On that platform the key is validated against this Workspace
              when it is attached, so a key-policy problem is reported as an error on this
              request. This field is write-once: once a key is attached to a Workspace it
              cannot be detached or replaced. To rotate key material, rotate the underlying
              key on your cloud KMS; the `external_key_id` stays the same.

          inference_data_privacy: Changes to where the Workspace's retained inference data and transcript copies
              go, and to whether Anthropic's human review applies. Requires the
              `efs-2026-10-01` `anthropic-beta` value. An omitted member is unchanged. Cannot
              be null. An Admin API key can't set this field, because it doesn't belong to a
              user or a service account. Use an API key that belongs to one, or an OAuth
              token.

          name: Name of the Workspace.

          tags: User-defined tags as string key-value pairs. Keys may not begin with
              `anthropic`.

          user_profile_id: ID of a user profile to attach to the Workspace. Every inference request through
              the Workspace must then name this user profile; the API rejects a request that
              names none or a different one. Once set, it can't be replaced or removed
              (sending the same ID again changes nothing); only deleting the user profile
              clears it. It can't be set on a Workspace whose External Key isn't bound to this
              user profile. The default Workspace can't have a user profile.

          betas: Optional. Send `efs-2026-10-01` in this header to use this endpoint's beta
              features: additional parameters, accepted values and response fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          BetaApprovalRequiredError:

          ExternalKeyValidationFailedError:

          ExternalKeyValidationTimedOutError:

          BetaExternalStorageNotAvailableError:

          BetaGrantRequiredError:

          BetaHumanReviewNotAvailableError:

          BetaHumanReviewOnWithExternalStorageError:

          BetaInvalidStorageARNError:

          KeyProfileMismatchError:

          BetaOrganizationNotEligibleError:

          BetaStorageAttachLimitReachedError:

          BetaStorageNotAttachableError:

          StorageProfileMismatchError:

          BetaStorageProfileStillRequiredError:

          BetaStorageVerificationFailedError:

          BetaTranscriptsStorageRequiredError:

          UserProfileNotFoundError:

          WorkspacePolicyViolationError:

          SandboxEgressRestrictedError:

          ExternalKeyChangedError:

          BetaStorageChangedConcurrentlyError:

          BetaWorkspaceChangedConcurrentlyError:

          BetaAuthorizationCheckUnavailableError:

          ChangeOutcomeUnknownError:
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        extra_headers = {
            **strip_not_given({"anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given}),
            **(extra_headers or {}),
        }
        return await self._post(
            path_template("/v1/organizations/workspaces/{workspace_id}", workspace_id=workspace_id),
            body={
                "data_residency": data_residency,
                "display_color": display_color,
                "external_key_id": external_key_id,
                "inference_data_privacy": inference_data_privacy,
                "name": name,
                "tags": tags,
                "user_profile_id": user_profile_id,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.organization.workspaces.update",
                span_route="/v1/organizations/workspaces/{workspace_id}",
                span_attributes={"anthropic.organization.workspace.id": workspace_id},
            ),
            cast_to=BetaWorkspace,
        )

    def list(
        self,
        *,
        after_id: str | Omit = omit,
        before_id: str | Omit = omit,
        ids: SequenceNotStr[str] | Omit = omit,
        include_archived: bool | Omit = omit,
        include_default: bool | Omit = omit,
        limit: int | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[BetaWorkspace, AsyncPage[BetaWorkspace]]:
        """
        List Workspaces

        Args:
          after_id: ID of the object to use as a cursor for pagination. When provided, returns the
              page of results immediately after this object.

          before_id: ID of the object to use as a cursor for pagination. When provided, returns the
              page of results immediately before this object.

          ids: Only the Workspaces with these IDs, at most 100. `include_archived` and
              `include_default` still apply, and IDs of Workspaces the caller can't list are
              left out.

          include_archived: Whether to include Workspaces that have been archived in the response

          include_default: Whether to include the organization's default Workspace in the response

          limit: Number of items to return per page.

              Defaults to `20`. Ranges from `1` to `1000`.

          betas: Optional. Send `efs-2026-10-01` in this header to use this endpoint's beta
              features: additional parameters, accepted values and response fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given({"anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given}),
            **(extra_headers or {}),
        }
        return self._get_api_list(
            "/v1/organizations/workspaces",
            page=AsyncPage[BetaWorkspace],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query={
                    "after_id": after_id,
                    "before_id": before_id,
                    "ids": ids,
                    "include_archived": include_archived,
                    "include_default": include_default,
                    "limit": limit,
                },
                qualifiers={"beta": "true"},
                span_name="anthropic.organization.workspaces.list",
                span_route="/v1/organizations/workspaces",
            ),
            model=BetaWorkspace,
        )

    async def archive(
        self,
        workspace_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaWorkspace:
        """Archive Workspace

        Args:
          betas: Optional.

        Send `efs-2026-10-01` in this header to use this endpoint's beta
              features: additional parameters, accepted values and response fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          SandboxEgressRestrictedError:

          StorageAttachedDuringArchiveError:
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        extra_headers = {
            **strip_not_given({"anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given}),
            **(extra_headers or {}),
        }
        return await self._post(
            path_template("/v1/organizations/workspaces/{workspace_id}/archive", workspace_id=workspace_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.organization.workspaces.archive",
                span_route="/v1/organizations/workspaces/{workspace_id}/archive",
                span_attributes={"anthropic.organization.workspace.id": workspace_id},
            ),
            cast_to=BetaWorkspace,
        )


class WorkspacesWithRawResponse:
    def __init__(self, workspaces: Workspaces) -> None:
        self._workspaces = workspaces

        self.create = to_raw_response_wrapper(
            workspaces.create,
        )
        self.retrieve = to_raw_response_wrapper(
            workspaces.retrieve,
        )
        self.update = to_raw_response_wrapper(
            workspaces.update,
        )
        self.list = to_raw_response_wrapper(
            workspaces.list,
        )
        self.archive = to_raw_response_wrapper(
            workspaces.archive,
        )

    @cached_property
    def rate_limits(self) -> RateLimitsWithRawResponse:
        return RateLimitsWithRawResponse(self._workspaces.rate_limits)

    @cached_property
    def members(self) -> MembersWithRawResponse:
        return MembersWithRawResponse(self._workspaces.members)

    @cached_property
    def service_accounts(self) -> ServiceAccountsWithRawResponse:
        return ServiceAccountsWithRawResponse(self._workspaces.service_accounts)


class AsyncWorkspacesWithRawResponse:
    def __init__(self, workspaces: AsyncWorkspaces) -> None:
        self._workspaces = workspaces

        self.create = async_to_raw_response_wrapper(
            workspaces.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            workspaces.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            workspaces.update,
        )
        self.list = async_to_raw_response_wrapper(
            workspaces.list,
        )
        self.archive = async_to_raw_response_wrapper(
            workspaces.archive,
        )

    @cached_property
    def rate_limits(self) -> AsyncRateLimitsWithRawResponse:
        return AsyncRateLimitsWithRawResponse(self._workspaces.rate_limits)

    @cached_property
    def members(self) -> AsyncMembersWithRawResponse:
        return AsyncMembersWithRawResponse(self._workspaces.members)

    @cached_property
    def service_accounts(self) -> AsyncServiceAccountsWithRawResponse:
        return AsyncServiceAccountsWithRawResponse(self._workspaces.service_accounts)


class WorkspacesWithStreamingResponse:
    def __init__(self, workspaces: Workspaces) -> None:
        self._workspaces = workspaces

        self.create = to_streamed_response_wrapper(
            workspaces.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            workspaces.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            workspaces.update,
        )
        self.list = to_streamed_response_wrapper(
            workspaces.list,
        )
        self.archive = to_streamed_response_wrapper(
            workspaces.archive,
        )

    @cached_property
    def rate_limits(self) -> RateLimitsWithStreamingResponse:
        return RateLimitsWithStreamingResponse(self._workspaces.rate_limits)

    @cached_property
    def members(self) -> MembersWithStreamingResponse:
        return MembersWithStreamingResponse(self._workspaces.members)

    @cached_property
    def service_accounts(self) -> ServiceAccountsWithStreamingResponse:
        return ServiceAccountsWithStreamingResponse(self._workspaces.service_accounts)


class AsyncWorkspacesWithStreamingResponse:
    def __init__(self, workspaces: AsyncWorkspaces) -> None:
        self._workspaces = workspaces

        self.create = async_to_streamed_response_wrapper(
            workspaces.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            workspaces.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            workspaces.update,
        )
        self.list = async_to_streamed_response_wrapper(
            workspaces.list,
        )
        self.archive = async_to_streamed_response_wrapper(
            workspaces.archive,
        )

    @cached_property
    def rate_limits(self) -> AsyncRateLimitsWithStreamingResponse:
        return AsyncRateLimitsWithStreamingResponse(self._workspaces.rate_limits)

    @cached_property
    def members(self) -> AsyncMembersWithStreamingResponse:
        return AsyncMembersWithStreamingResponse(self._workspaces.members)

    @cached_property
    def service_accounts(self) -> AsyncServiceAccountsWithStreamingResponse:
        return AsyncServiceAccountsWithStreamingResponse(self._workspaces.service_accounts)
