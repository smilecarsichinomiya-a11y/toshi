from __future__ import annotations

from typing import Mapping, Optional, cast

import httpx2

from .._files import deepcopy_with_paths
from .._types import Body, Omit, Query, Headers, NotGiven, FileTypes, SequenceNotStr, omit, not_given
from .._utils import extract_files, path_template, strip_not_given
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    BinaryAPIResponse,
    AsyncBinaryAPIResponse,
    StreamedBinaryAPIResponse,
    AsyncStreamedBinaryAPIResponse,
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    to_custom_raw_response_wrapper,
    async_to_streamed_response_wrapper,
    to_custom_streamed_response_wrapper,
    async_to_custom_raw_response_wrapper,
    async_to_custom_streamed_response_wrapper,
)
from ..pagination import SyncPageCursor, AsyncPageCursor
from .._base_client import (
    AsyncPaginator,
    merge_headers,
    make_request_options,
)
from ..types.deleted_file import DeletedFile
from ..types.file_metadata import FileMetadata
from ..lib._stainless_helpers import stainless_helper_header_from_file as _stainless_helper_header_from_file

__all__ = ["Files", "AsyncFiles"]


class Files(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> FilesWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return FilesWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> FilesWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return FilesWithStreamingResponse(self)

    def list(
        self,
        *,
        ids: Optional[SequenceNotStr[str]] | Omit = omit,
        limit: int | Omit = omit,
        page: Optional[str] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> SyncPageCursor[FileMetadata]:
        """
        List Files

        Args:
          ids: Restrict the result set to Files whose `id` is in this list. At most 100 entries
              (after de-duplication). Mutually exclusive with `page` and `limit`. When
              supplied, the response is always a single page (`next_page` is null). IDs that
              do not resolve to a visible File — including deleted Files — are silently
              omitted.

          limit: Number of items to return per page.

              Defaults to `20`. Ranges from `1` to `1000`.

          page: Opaque page cursor returned in a prior list response's `next_page`. Prefixed
              `page_`.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ClaudeCodeKeyCreatorNotMemberError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          OrganizationOnHoldError:
        """
        extra_headers = {**strip_not_given({"anthropic-workspace-id": workspace_id}), **(extra_headers or {})}
        return self._get_api_list(
            "/v1/files",
            page=SyncPageCursor[FileMetadata],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query={
                    "ids": ids,
                    "limit": limit,
                    "page": page,
                },
                span_name="anthropic.files.list",
                span_route="/v1/files",
            ),
            model=FileMetadata,
        )

    def delete(
        self,
        file_id: str,
        *,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> DeletedFile:
        """
        Delete File

        Args:
          file_id: ID of the File.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ClaudeCodeKeyCreatorNotMemberError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          OrganizationOnHoldError:
        """
        if not file_id:
            raise ValueError(f"Expected a non-empty value for `file_id` but received {file_id!r}")
        extra_headers = {**strip_not_given({"anthropic-workspace-id": workspace_id}), **(extra_headers or {})}
        return self._delete(
            path_template("/v1/files/{file_id}", file_id=file_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.files.delete",
                span_route="/v1/files/{file_id}",
                span_attributes={"anthropic.file.id": file_id},
            ),
            cast_to=DeletedFile,
        )

    def download(
        self,
        file_id: str,
        *,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BinaryAPIResponse:
        """
        Download File

        Args:
          file_id: ID of the File.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ClaudeCodeKeyCreatorNotMemberError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          FileNotDownloadableError:

          OrganizationOnHoldError:

          FileExpiredError:
        """
        if not file_id:
            raise ValueError(f"Expected a non-empty value for `file_id` but received {file_id!r}")
        extra_headers = {"Accept": "application/binary", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"anthropic-workspace-id": workspace_id}), **(extra_headers or {})}
        return self._get(
            path_template("/v1/files/{file_id}/content", file_id=file_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.files.download",
                span_route="/v1/files/{file_id}/content",
                span_attributes={"anthropic.file.id": file_id},
            ),
            cast_to=BinaryAPIResponse,
        )

    def retrieve_metadata(
        self,
        file_id: str,
        *,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> FileMetadata:
        """
        Get File Metadata

        Args:
          file_id: ID of the File.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ClaudeCodeKeyCreatorNotMemberError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          OrganizationOnHoldError:
        """
        if not file_id:
            raise ValueError(f"Expected a non-empty value for `file_id` but received {file_id!r}")
        extra_headers = {**strip_not_given({"anthropic-workspace-id": workspace_id}), **(extra_headers or {})}
        return self._get(
            path_template("/v1/files/{file_id}", file_id=file_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.files.retrieve_metadata",
                span_route="/v1/files/{file_id}",
                span_attributes={"anthropic.file.id": file_id},
            ),
            cast_to=FileMetadata,
        )

    def upload(
        self,
        *,
        file: FileTypes,
        expires_in_seconds: int | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> FileMetadata:
        """Upload File

        Args:
          file: The file to upload.

        Only the final path component of the part's `filename` is
              kept; an absent or empty `filename` is replaced with `unnamed` plus the
              extension for the file's stored `mime_type`, when known.

          expires_in_seconds: Seconds from upload until the file expires and its bytes become permanently
              unavailable. Must be between 3600 (one hour) and 7776000 (ninety days).

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ClaudeCodeKeyCreatorNotMemberError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          OrganizationOnHoldError:

          StorageQuotaExceededError:
        """
        extra_headers = {**strip_not_given({"anthropic-workspace-id": workspace_id}), **(extra_headers or {})}
        extra_headers = merge_headers(_stainless_helper_header_from_file(file), extra_headers or {})
        body = deepcopy_with_paths(
            {
                "file": file,
                "expires_in_seconds": expires_in_seconds,
            },
            [["file"]],
        )
        files = extract_files(cast(Mapping[str, object], body), paths=[["file"]])
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return self._post(
            "/v1/files",
            body=body,
            files=files,
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.files.upload",
                span_route="/v1/files",
                span_created_id="anthropic.file.id",
            ),
            cast_to=FileMetadata,
        )


class AsyncFiles(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncFilesWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return AsyncFilesWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncFilesWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return AsyncFilesWithStreamingResponse(self)

    def list(
        self,
        *,
        ids: Optional[SequenceNotStr[str]] | Omit = omit,
        limit: int | Omit = omit,
        page: Optional[str] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[FileMetadata, AsyncPageCursor[FileMetadata]]:
        """
        List Files

        Args:
          ids: Restrict the result set to Files whose `id` is in this list. At most 100 entries
              (after de-duplication). Mutually exclusive with `page` and `limit`. When
              supplied, the response is always a single page (`next_page` is null). IDs that
              do not resolve to a visible File — including deleted Files — are silently
              omitted.

          limit: Number of items to return per page.

              Defaults to `20`. Ranges from `1` to `1000`.

          page: Opaque page cursor returned in a prior list response's `next_page`. Prefixed
              `page_`.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ClaudeCodeKeyCreatorNotMemberError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          OrganizationOnHoldError:
        """
        extra_headers = {**strip_not_given({"anthropic-workspace-id": workspace_id}), **(extra_headers or {})}
        return self._get_api_list(
            "/v1/files",
            page=AsyncPageCursor[FileMetadata],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query={
                    "ids": ids,
                    "limit": limit,
                    "page": page,
                },
                span_name="anthropic.files.list",
                span_route="/v1/files",
            ),
            model=FileMetadata,
        )

    async def delete(
        self,
        file_id: str,
        *,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> DeletedFile:
        """
        Delete File

        Args:
          file_id: ID of the File.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ClaudeCodeKeyCreatorNotMemberError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          OrganizationOnHoldError:
        """
        if not file_id:
            raise ValueError(f"Expected a non-empty value for `file_id` but received {file_id!r}")
        extra_headers = {**strip_not_given({"anthropic-workspace-id": workspace_id}), **(extra_headers or {})}
        return await self._delete(
            path_template("/v1/files/{file_id}", file_id=file_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.files.delete",
                span_route="/v1/files/{file_id}",
                span_attributes={"anthropic.file.id": file_id},
            ),
            cast_to=DeletedFile,
        )

    async def download(
        self,
        file_id: str,
        *,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> AsyncBinaryAPIResponse:
        """
        Download File

        Args:
          file_id: ID of the File.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ClaudeCodeKeyCreatorNotMemberError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          FileNotDownloadableError:

          OrganizationOnHoldError:

          FileExpiredError:
        """
        if not file_id:
            raise ValueError(f"Expected a non-empty value for `file_id` but received {file_id!r}")
        extra_headers = {"Accept": "application/binary", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"anthropic-workspace-id": workspace_id}), **(extra_headers or {})}
        return await self._get(
            path_template("/v1/files/{file_id}/content", file_id=file_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.files.download",
                span_route="/v1/files/{file_id}/content",
                span_attributes={"anthropic.file.id": file_id},
            ),
            cast_to=AsyncBinaryAPIResponse,
        )

    async def retrieve_metadata(
        self,
        file_id: str,
        *,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> FileMetadata:
        """
        Get File Metadata

        Args:
          file_id: ID of the File.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ClaudeCodeKeyCreatorNotMemberError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          OrganizationOnHoldError:
        """
        if not file_id:
            raise ValueError(f"Expected a non-empty value for `file_id` but received {file_id!r}")
        extra_headers = {**strip_not_given({"anthropic-workspace-id": workspace_id}), **(extra_headers or {})}
        return await self._get(
            path_template("/v1/files/{file_id}", file_id=file_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.files.retrieve_metadata",
                span_route="/v1/files/{file_id}",
                span_attributes={"anthropic.file.id": file_id},
            ),
            cast_to=FileMetadata,
        )

    async def upload(
        self,
        *,
        file: FileTypes,
        expires_in_seconds: int | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> FileMetadata:
        """Upload File

        Args:
          file: The file to upload.

        Only the final path component of the part's `filename` is
              kept; an absent or empty `filename` is replaced with `unnamed` plus the
              extension for the file's stored `mime_type`, when known.

          expires_in_seconds: Seconds from upload until the file expires and its bytes become permanently
              unavailable. Must be between 3600 (one hour) and 7776000 (ninety days).

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ClaudeCodeKeyCreatorNotMemberError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          OrganizationOnHoldError:

          StorageQuotaExceededError:
        """
        extra_headers = {**strip_not_given({"anthropic-workspace-id": workspace_id}), **(extra_headers or {})}
        extra_headers = merge_headers(_stainless_helper_header_from_file(file), extra_headers or {})
        body = deepcopy_with_paths(
            {
                "file": file,
                "expires_in_seconds": expires_in_seconds,
            },
            [["file"]],
        )
        files = extract_files(cast(Mapping[str, object], body), paths=[["file"]])
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return await self._post(
            "/v1/files",
            body=body,
            files=files,
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.files.upload",
                span_route="/v1/files",
                span_created_id="anthropic.file.id",
            ),
            cast_to=FileMetadata,
        )


class FilesWithRawResponse:
    def __init__(self, files: Files) -> None:
        self._files = files

        self.list = to_raw_response_wrapper(
            files.list,
        )
        self.delete = to_raw_response_wrapper(
            files.delete,
        )
        self.download = to_custom_raw_response_wrapper(
            files.download,
            BinaryAPIResponse,
        )
        self.retrieve_metadata = to_raw_response_wrapper(
            files.retrieve_metadata,
        )
        self.upload = to_raw_response_wrapper(
            files.upload,
        )


class AsyncFilesWithRawResponse:
    def __init__(self, files: AsyncFiles) -> None:
        self._files = files

        self.list = async_to_raw_response_wrapper(
            files.list,
        )
        self.delete = async_to_raw_response_wrapper(
            files.delete,
        )
        self.download = async_to_custom_raw_response_wrapper(
            files.download,
            AsyncBinaryAPIResponse,
        )
        self.retrieve_metadata = async_to_raw_response_wrapper(
            files.retrieve_metadata,
        )
        self.upload = async_to_raw_response_wrapper(
            files.upload,
        )


class FilesWithStreamingResponse:
    def __init__(self, files: Files) -> None:
        self._files = files

        self.list = to_streamed_response_wrapper(
            files.list,
        )
        self.delete = to_streamed_response_wrapper(
            files.delete,
        )
        self.download = to_custom_streamed_response_wrapper(
            files.download,
            StreamedBinaryAPIResponse,
        )
        self.retrieve_metadata = to_streamed_response_wrapper(
            files.retrieve_metadata,
        )
        self.upload = to_streamed_response_wrapper(
            files.upload,
        )


class AsyncFilesWithStreamingResponse:
    def __init__(self, files: AsyncFiles) -> None:
        self._files = files

        self.list = async_to_streamed_response_wrapper(
            files.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            files.delete,
        )
        self.download = async_to_custom_streamed_response_wrapper(
            files.download,
            AsyncStreamedBinaryAPIResponse,
        )
        self.retrieve_metadata = async_to_streamed_response_wrapper(
            files.retrieve_metadata,
        )
        self.upload = async_to_streamed_response_wrapper(
            files.upload,
        )
